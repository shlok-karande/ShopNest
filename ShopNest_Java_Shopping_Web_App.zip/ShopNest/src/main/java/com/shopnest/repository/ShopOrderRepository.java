package com.shopnest.repository;
import com.shopnest.model.ShopOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface ShopOrderRepository extends JpaRepository<ShopOrder, Long> {
    Optional<ShopOrder> findByIdAndCustomerId(Long id, Long customerId);
}
